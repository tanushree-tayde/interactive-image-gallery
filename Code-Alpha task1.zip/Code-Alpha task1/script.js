let activeImageList = [];
let currentPhotoIndex = 0;

const popupOverlay = document.getElementById("customLightbox");
const popupDisplayImg = document.getElementById("lightboxImg");
const closeBtnHandle = document.getElementById("closeBtn");
const prevBtnHandle = document.getElementById("prevBtn");
const nextBtnHandle = document.getElementById("nextBtn");

if (popupOverlay) {
    const thumbnails = document.querySelectorAll(".gallery-item img");
    activeImageList = Array.from(thumbnails).map(img => img.getAttribute("src"));
    document.querySelectorAll(".gallery-item").forEach((item, clickedIndex) => {
        item.addEventListener("click", (event) => {
            if (item.tagName.toLowerCase() === 'a') {
                event.preventDefault();
            }
            currentPhotoIndex = clickedIndex;
            renderSelectedPhoto();
        });
    });
    nextBtnHandle.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        currentPhotoIndex = (currentPhotoIndex === activeImageList.length - 1) ? 0 : currentPhotoIndex + 1;
        renderSelectedPhoto();
    });
    prevBtnHandle.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        currentPhotoIndex = (currentPhotoIndex === 0) ? activeImageList.length - 1 : currentPhotoIndex - 1;
        renderSelectedPhoto();
    });
    closeBtnHandle.addEventListener("click", () => {
        popupOverlay.classList.remove("active");
    });
    popupOverlay.addEventListener("click", (event) => {
        if (event.target === popupOverlay) {
            popupOverlay.classList.remove("active");
        }
    });
}

function renderSelectedPhoto() {
    if (activeImageList[currentPhotoIndex]) {
        popupDisplayImg.src = activeImageList[currentPhotoIndex];
        popupOverlay.classList.add("active");
    }
}
